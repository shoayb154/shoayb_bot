كيفيه تنصيب احدث سورس عربي DEVKEEPER

اولا افتح ترمنال وخلي هذا

 sudo apt-get update

وبعده هذا 

redis-server

عوفه مفتوح وفتح ترمنال جديد
وخلي هذا

sudo apt-get install libreadline-dev libconfig-dev libssl-dev lua5.2 liblua5.2-dev lua-socket lua-sec lua-expat libevent-dev make unzip git redis-server autoconf g++ libjansson-dev libpython-dev expat libexpat1-dev

وبعده هذا 

 git clone https://github.com/ldevl/DEVKEEPER.git

وبعده هذا

 cd DEVKEEPER

وهذ 

 chmod +x launch.sh
 
وبعدين هذا

./launch.sh install

وهذا

 ./launch.sh
بعدها يطلب رقم ودخل ررقم ومبروك عليك البوت 
بعدها افتح ترمنال جديد واكتب 
redis-server

 ودوس انتر 
 وسوي رن من ملف لانج
بعد متسوي رن افتح ترمنال جديد واكتب 
 
 cd DEVKEEPER
 
انتر وبعدها هل امر 

 bash DEVKEEPER.sh -t
 
 انتظر 5 ثواني يشتغل بوت 
هذا ملف يقلل وكفات بوت 
