
do

function run(msg, matches)
  return "🏌🏻اهلاً بكم في سورس كيبر🏌🏻      ◈⊙◈ الاصدار :الثاني                       ◈⊙◈ مطور السورس #القيصر                   ◈⊙◈ الموقع :https://github.com/ldevl/DEVKEEPER.git                                                  ◈⊙◈ قناة السورس :@keeper_ch                                                ◈⊙◈ معرف الـ مطور : @llX8Xl"
end

return {
  patterns = {
    "^الاصدار"
  }, 
  run = run 
}

end