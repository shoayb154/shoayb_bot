do

function run(msg, matches)
return [[
البوت الذي يعمل على مجموعات السوبر
التي تصل الى 5k 🎭

تم صنع البوت بواسطةة المطور
 
  〘 آلقہٰٰيِٰہٰٰصۛہٰٰڕٰ_‏ᎯᏞᏫᎪᏕᏋᏒ 〙
      @karrar_alqaser

  〘 بوت تواصل المحظورين  〙
         @alqaserBOT

    〘 قنــاةٌٰ الــبوت  〙
         @keeper_ch
  
     〘 رمـٰـــــزيُـٰٰـاِت 〙
          @llX8Xll
  
]]
end

return {
description = "Shows bot q", 
usage = "spam Shows bot q",
patterns = {
"المطور"
},
run = run 
}
end
